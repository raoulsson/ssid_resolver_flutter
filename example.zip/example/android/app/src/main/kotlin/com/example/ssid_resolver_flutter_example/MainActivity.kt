package com.example.ssid_resolver_flutter_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
