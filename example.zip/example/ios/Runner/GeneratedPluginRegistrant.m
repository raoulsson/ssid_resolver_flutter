//
//  Generated file. Do not edit.
//

// clang-format off

#import "GeneratedPluginRegistrant.h"

#if __has_include(<integration_test/IntegrationTestPlugin.h>)
#import <integration_test/IntegrationTestPlugin.h>
#else
@import integration_test;
#endif

#if __has_include(<ssid_resolver_flutter/SsidResolverFlutterPlugin.h>)
#import <ssid_resolver_flutter/SsidResolverFlutterPlugin.h>
#else
@import ssid_resolver_flutter;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [IntegrationTestPlugin registerWithRegistrar:[registry registrarForPlugin:@"IntegrationTestPlugin"]];
  [SsidResolverFlutterPlugin registerWithRegistrar:[registry registrarForPlugin:@"SsidResolverFlutterPlugin"]];
}

@end
