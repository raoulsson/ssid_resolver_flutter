// example/lib/main.dart
import 'package:flutter/material.dart';
import 'package:ssid_resolver_flutter/ssid_resolver_flutter.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  final _ssidResolver = SsidResolverFlutter();
  String _ssid = 'Unknown';
  String _status = 'Unknown';
  String? _error;

  @override
  void initState() {
    super.initState();
    _checkPermissions();
  }

  Future<void> _checkPermissions() async {
    try {
      final status = await _ssidResolver.checkPermissionStatus();
      setState(() {
        _status = status.status;
        _error = status.errorMessage;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
      });
    }
  }

  Future<void> _requestPermissions() async {
    try {
      final status = await _ssidResolver.requestPermission();
      setState(() {
        _status = status.status;
        _error = status.errorMessage;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
      });
    }
  }

  Future<void> _getSsid() async {
    try {
      final ssid = await _ssidResolver.fetchSsid();
      setState(() {
        _ssid = ssid;
        _error = null;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(title: const Text('SSID Resolver Example')),
        body: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('Permission Status: $_status'),
              if (_error != null)
                Text(
                  'Error: $_error',
                  style: const TextStyle(color: Colors.red),
                ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: _requestPermissions,
                child: const Text('Request Permissions'),
              ),
              const SizedBox(height: 16),
              Text('Current SSID: $_ssid'),
              ElevatedButton(
                onPressed: _getSsid,
                child: const Text('Get SSID'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}